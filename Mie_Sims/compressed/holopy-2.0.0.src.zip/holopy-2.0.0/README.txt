holopy
------

Python package for analyzing digital holograms.  This includes code
for loading raw data files, preprocessing, reconstructing, and
fitting.

For installation, see INSTALL.txt
