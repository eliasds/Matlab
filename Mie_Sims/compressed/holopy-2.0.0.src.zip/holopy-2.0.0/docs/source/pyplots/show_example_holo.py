import holopy as hp
from holopy.core.io import get_example_data
holo = get_example_data('image0001.yaml')
hp.show(holo)
