Download HoloPy
===============

2.0.0
-----

* `holopy-2.0.0.linux-x86_64.tar.gz
  <http://www.manoharan.seas.harvard.edu/holopy/files/holopy-2.0.0.linux-x86_64.tar.gz>`_ For modern 64 bit Linux. 
* `HoloPy-2.0.0.win32-py2.7.msi
  <http://www.manoharan.seas.harvard.edu/holopy/files/HoloPy-2.0.0.win32-py2.7.msi>`_ Compiled on Windows 7 32 bit, will hopefully work on related versions
* `holopy-2.0.0.ubuntu-11.10-x86_64.tar.gz
  <http://www.manoharan.seas.harvard.edu/holopy/files/holopy-2.0.0.ubuntu-11.10-x86_64.tar.gz>`_
  For older older versions of linux (we compiled it on 64 bit Ubuntu
  11.10)
* `holopy-2.0.0.src.zip
  <http://www.manoharan.seas.harvard.edu/holopy/files/holopy-2.0.0.src.zip>`_
  If you just need to propagate/reconstruct and want a smaller
  download, or if you plan to compile yourself.

Mac build (hopefully) coming soon. 

