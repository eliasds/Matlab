scattering Package
==================

.. automodule:: holopy.scattering

.. toctree::

    holopy.scattering.scatterer
    holopy.scattering.theory

:mod:`geometry` Module
----------------------

.. automodule:: holopy.scattering.geometry
    :members:
    :show-inheritance:

