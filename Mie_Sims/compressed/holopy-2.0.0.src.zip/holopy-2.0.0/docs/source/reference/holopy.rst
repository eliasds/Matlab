:mod:`holopy` Code Reference
----------------------------

.. automodule:: holopy

.. toctree::

    holopy.core
    holopy.propagation
    holopy.scattering
    holopy.fitting
    holopy.vis

	
