propagation Package
===================

.. automodule:: holopy.propagation

.. autofunction:: holopy.propagation.convolution_propagation.propagate

