vis Package
===========

:mod:`vis` Package
------------------

.. automodule:: holopy.vis
    :members:
    :show-inheritance:

:mod:`show` Module
------------------

.. automodule:: holopy.vis.show
    :members:
    :show-inheritance:

