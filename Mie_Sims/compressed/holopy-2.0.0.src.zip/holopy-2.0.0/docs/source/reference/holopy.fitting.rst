fitting Package
===============

.. automodule:: holopy.fitting

:mod:`fit` Module
----------------------

.. automodule:: holopy.fitting.fit
    :members:
    :show-inheritance:

	   
:mod:`parameter` Module
-----------------------

.. automodule:: holopy.fitting.parameter
    :members:
    :show-inheritance:

:mod:`model` Module
-------------------

.. automodule:: holopy.fitting.model
    :members:
    :show-inheritance:
	   
:mod:`minimizer` Module
-----------------------

.. automodule:: holopy.fitting.minimizer
    :members:
    :show-inheritance:



