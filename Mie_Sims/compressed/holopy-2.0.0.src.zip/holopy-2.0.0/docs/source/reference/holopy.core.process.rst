process Package
===============

:mod:`process` Package
----------------------

.. automodule:: holopy.core.process
    :members:
    :show-inheritance:

:mod:`centerfinder` Module
--------------------------

.. automodule:: holopy.core.process.centerfinder
    :members:
    :show-inheritance:

:mod:`enhance` Module
---------------------

.. automodule:: holopy.core.process.enhance
    :members:
    :show-inheritance:

:mod:`filter` Module
--------------------

.. automodule:: holopy.core.process.filter
    :members:
    :show-inheritance:

