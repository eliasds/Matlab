metadata Module
===============

.. automodule:: holopy.core.metadata
    :members: Optics, Angles
