marray Module
=============

.. automodule:: holopy.core.marray
    :members: 
