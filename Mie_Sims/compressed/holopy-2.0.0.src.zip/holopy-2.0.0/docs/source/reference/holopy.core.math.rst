Math Module
===========

.. automodule:: holopy.core.math
    :members:
