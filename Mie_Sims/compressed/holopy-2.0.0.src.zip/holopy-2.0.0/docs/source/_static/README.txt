default.css from matplotlib sampledoc package
http://matplotlib.svn.sourceforge.net/viewvc/matplotlib/trunk/sampledoc_tut/
