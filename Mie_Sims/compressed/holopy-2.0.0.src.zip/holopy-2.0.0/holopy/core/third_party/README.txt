This directory contains third party code used by holopy.  Code in this
directory may be subject to different licenses than the rest of
holopy.  
