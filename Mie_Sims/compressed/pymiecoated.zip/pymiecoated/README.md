A Python code for computing the scattering properties of single- and dual-layered spheres with an easy-to-use object oriented interface.

[See the installation and usage instructions](https://github.com/jleinonen/pymiecoated/wiki/Instructions)

[Download the code](https://github.com/jleinonen/pymiecoated/releases).

Based on code by C. Mätzler; ported and published with permission.

Requires NumPy and SciPy.
