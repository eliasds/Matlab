# -*- coding: utf-8 -*-
#######################################################
#
# OpenMie
#
# A code to calculate Mie scattering from spheres and 
# spherical shells.
#
# See Readme.pdf in documentation directory for theory.
#
# (C) Magnus Lundmark 2009
#######################################################

j = complex(0.,1.)