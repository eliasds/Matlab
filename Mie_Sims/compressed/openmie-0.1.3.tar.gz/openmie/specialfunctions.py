# -*- coding: utf-8 -*-
######################################################
#
# OpenMie
#
# A code to calculate Mie scattering from spheres and 
# spherical shells.
#
# See Readme.pdf in documentation directory for theory.
#
# (C) Magnus Lundmark 2009
#######################################################

from scipy import sqrt
from scipy.special import jv,yv,hankel2,legendre
from numpy import poly1d, polyder,cos,sin,pi,linspace
#import sys

# Schelkunoffs alternative bessel functions
def AltJ( nu , z ):
    return 1.2533141373155001*sqrt(z)*jv( nu+.5 , z)

def AltJp( nu , z ):
    c = sqrt(z)
    return 1.2533141373155001*( (1+nu)/c*jv(nu+.5,z) - c*jv(nu+1.5,z))

def AltY( nu , z ):
    return 1.2533141373155001*sqrt(z)*yv( nu+.5 , z)

def AltYp( nu , z ):
    c = sqrt(z)
    return 1.2533141373155001*( (1+nu)/c*yv(nu+.5,z) - c*yv(nu+1.5,z))

def AltH2( nu , z ):
    return 1.2533141373155001*sqrt(z)*hankel2( nu+.5 , z)

def AltH2p( nu , z ):
    c = sqrt(z)
    return 1.2533141373155001*( (1+nu)/c*hankel2(nu+.5,z) - c*hankel2(nu+1.5,z))

def Pn1S( n , x ):
    if x==0:
       return -n*(n+1)*.5
    elif x==pi:
       return (-1)**n*n*(n+1)*.5
    else:
       p = polyder( legendre(n) )
       return -p( cos(x) )
   
def Pn1pS( n , x ):
    if x==0:
       return n*(n+1)*.5
    elif x==pi:
       return (-1)**n*n*(n+1)*.5
    else:
       p1 = polyder( legendre(n) )
       p2 = polyder( legendre(n+1) )
       return -cos(x)*(n+1)*p1( cos(x) ) + n*p2( cos(x) )



#print dir(scipy)
#a = pi*.5
#print 'a       AltJ(1,a)       AltJp(1,a)'
#print a, AltJ( 1 , a ), AltJp( 1 , a )
#print 'a       AltY(1,a)       AltYp(1,a)'
#print a, AltY( 1 , a ), AltYp( 1 , a )
#print 'a       AltH2(1,a)       AltH2p(1,a)'
#print a, AltH2( 1 , a ), AltH2p( 1 , a )
#for a in linspace(0,pi,50):
#   b = Pn1pS(50,a)