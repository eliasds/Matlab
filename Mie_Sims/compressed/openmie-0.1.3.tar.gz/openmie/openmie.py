# -*- coding: utf-8 -*-
#######################################################
#
# OpenMie
#
# A code to calculate Mie scattering from spheres and 
# spherical shells.
#
# See Readme.pdf in documentation directory for theory.
#
# (C) Magnus Lundmark 2009
#######################################################

from specialfunctions import *
import pecsphere
import dielectricsphere
from field import point, field
from scipy import exp, log10
from numpy import arange, zeros, linspace, real, imag
from constants import j
import matplotlib.pyplot as plt

points = list()
ScatteredField = list()
IncidentField = list()
TotalField = list()
m = 0

#mysphere = dielectricsphere.dielectricsphere( 1. , 2*pi , 30 , 4. , 2. )
mysphere = pecsphere.pecsphere( 1. , 2*pi , 30 )

xx = linspace(-1.2 , 1.5 , 501)
yy = linspace(-1.2 , 1.5 , 501)
zz = linspace(-1.4 , 1.5 , 501)


for m in range(len(xx)):
   points.append( point( (xx[m],yy[m],zz[m]) ) )
   TotalField.append( mysphere.ScatteredElectric( points[m] ) )
   f = TotalField[m]
   rex = str(real( f.cartesian[0] ))
   imx = str(imag( f.cartesian[0] ))
   rey = str(real( f.cartesian[1] ))
   imy = str(imag( f.cartesian[1] ))
   rez = str(real( f.cartesian[2] ))
   imz = str(imag( f.cartesian[2] ))
   s = str(m/500.) + ' ' 
   s = s + rex + ' ' + imx + ' '
   s = s + rey + ' ' + imy + ' '
   s = s + rez + ' ' + imz + ' '
   print s


theta = arange( 0. , 180. , 1. )*pi/180 
myphi   = 0.
m       = 0
Gtheta = zeros( len( theta ))
Gphi   = zeros( len( theta ))

#for mytheta in theta:
  #ff = mysphere.ScatteredFarField( point( (1 , mytheta , myphi) , 'spherical') )
  #Gtheta[m] = abs(ff.spherical[1])
  #Gphi[m]   = abs(ff.spherical[2])
  #s = str(mytheta) + ' ' 
  #s = s + str(real(Gtheta[m])) + ' '  + str(imag(Gtheta[m])) + ' ' 
  #s = s + str(real(Gphi[m])) + ' '  + str(imag(Gphi[m]))
  #print s
  #m += 1

#plt.plot( theta*180/pi , 10*log10(Gtheta) )
#plt.plot( theta*180/pi , 10*log10(Gphi  ) )
#plt.grid( True )
#plt.show()


#for p in points:
  #Er = E_r( N , 2*pi , a , p )
  #Et = E_theta( N , 2*pi , a , p )
  #Ep = E_phi( N , 2*pi , a , p )
  #ScatteredField.append( field( (Er,Et,Ep) , p , 'spherical' ) )
  #Ex = exp( -j*k0*p.cartesian[2] )
  #IncidentField.append( field( (Ex,0.,0.) , p , 'cartesian' ) )
  #TotalField.append( IncidentField[m] + ScatteredField[m] )
  #print 'Total field:'
  #print TotalField[m]
  #print 'Scattered field:'
  #print ScatteredField[m]
  #print 'At', p
  #print ''
  #m = m + 1
