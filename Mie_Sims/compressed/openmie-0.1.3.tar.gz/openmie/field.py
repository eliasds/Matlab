# -*- coding: utf-8 -*-
#######################################################
#
# OpenMie
#
# A code to calculate Mie scattering from spheres and 
# spherical shells.
#
# See Readme.pdf in documentation directory for theory.
#
# (C) Magnus Lundmark 2009
#######################################################

from numpy import array,pi
from math import atan2, hypot, sin,cos

class field:
  'A field is a vector field at a point'
  def __init__(self , myField=tuple() , myPoint=tuple() , coord='cartesian' ):
    if len( myField ) == 0:
      self.cartesian = tuple()
      self.spherical = tuple()
      self.location  = point()
      return
    if coord == 'cartesian':
      self.cartesian = myField
      theta  = myPoint.spherical[1]
      phi    = myPoint.spherical[2]
      Ar     = myField[0]*sin(theta)*cos(phi) +\
               myField[1]*sin(theta)*sin(phi) +\
               myField[2]*cos(theta)
      Atheta = myField[0]*cos(theta)*cos(phi) +\
               myField[1]*cos(theta)*sin(phi) -\
               myField[2]*sin(theta)
      Aphi   =-myField[0]*sin(phi) +\
               myField[1]*cos(phi)
      self.spherical = tuple( (Ar,Atheta,Aphi) )
      self.location  = myPoint
    elif coord == 'spherical':
      self.spherical = myField
      theta = myPoint.spherical[1]
      phi   = myPoint.spherical[2]
      #
      Ax = myField[0]*sin(theta)*cos(phi) +\
           myField[1]*cos(theta)*cos(phi) -\
           myField[2]*sin(phi)
      #
      Ay = myField[0]*sin(theta)*sin(phi) +\
           myField[1]*cos(theta)*sin(phi) +\
           myField[2]*cos(phi)
      #
      Az = myField[0]*cos(theta) -\
	   myField[1]*sin(theta)
      self.cartesian = tuple( (Ax,Ay,Az))
      self.location  = myPoint
    else:
      print 'Unrecognized coordinate system, returning empty field'
      self.cartesian = tuple()
      self.spherical = tuple()
      self.location  = tuple()
      return
  def __abs__(self):
    tmp = hypot( abs(self.cartesian[0]) , abs(self.cartesian[1]) )
    return  hypot( tmp , abs(self.cartesian[2]) )
  def __add__(self, f):
    if not self.location==f.location:
      print 'Can not add fields at different locations'
      return self
    else:
      Ax = self.cartesian[0] + f.cartesian[0]
      Ay = self.cartesian[1] + f.cartesian[1]
      Az = self.cartesian[2] + f.cartesian[2]
      return field( (Ax,Ay,Az) , self.location , 'cartesian' ) 
  def __sub__(self, f):
    if not self.location==f.location:
      print 'Can not subtract fields at different locations'
      return self
    else:
      Ax = self.cartesian[0] - f.cartesian[0]
      Ay = self.cartesian[1] - f.cartesian[1]
      Az = self.cartesian[2] - f.cartesian[2]
      return field( (Ax,Ay,Az) , self.location , 'cartesian' )
  def __str__(self):
    s =     'Ex: ' + str(self.cartesian[0]) + '\012'
    s = s + 'Ey: ' + str(self.cartesian[1]) + '\012'
    s = s + 'Ez: ' + str(self.cartesian[2]) + '\012'
    s = s + 'Er: ' + str(self.spherical[0]) + '\012'
    s = s + 'Et: ' + str(self.spherical[1]) + '\012'
    s = s + 'Ep: ' + str(self.spherical[2]) + '\012'
    return s
    

class point:
  'A class storing points in space'
  d2r = 0.017453292519943295
  def __init__(self, myTuple=tuple() , coord='cartesian' ):
    if len(myTuple) == 0:
      self.cartesian = tuple()
      self.spherical = tuple()
      return
    if coord == 'cartesian':
      self.cartesian = myTuple   
      tmp = hypot( myTuple[0] , myTuple[1] )
      r = hypot( tmp , myTuple[2] )
      theta = atan2( tmp , myTuple[2] )
      phi = atan2( myTuple[1] , myTuple[0] )
      self.spherical = tuple( (r,theta,phi) )
    elif coord == 'spherical':
      self.spherical = myTuple
      x = myTuple[0]*sin(myTuple[1])*cos(myTuple[2])
      y = myTuple[0]*sin(myTuple[1])*sin(myTuple[2])
      z = myTuple[0]*cos(myTuple[1])
      self.cartesian = tuple( (x,y,z) )
    elif coord == 'spherical_deg':
      self.spherical = tuple( (myTuple[0] , myTuple[1]*self.d2r , myTuple[2]*self.d2r) )
      x = myTuple[0]*sin(myTuple[1]*self.d2r)*cos(myTuple[2]*self.d2r)
      y = myTuple[0]*sin(myTuple[1]*self.d2r)*sin(myTuple[2]*self.d2r)
      z = myTuple[0]*cos(myTuple[1]*self.d2r)
      self.cartesian = tuple( (x,y,z) )
    else:
      print 'Unrecognized option, returning zero'
      self.cartesian = tuple()
      self.spherical = tuple()
      return

  def __str__(self):
    s =  'x,y,z: ( ' + str(self.cartesian[0]) + ' , ' + str(self.cartesian[1]) + ' , ' + str(self.cartesian[2]) + ' )\012'
    s = s + 'r,t,p: ( ' + str(self.spherical[0]) + ' , ' + str(self.spherical[1]) + ' , ' + str(self.spherical[2]) + ' )'
    return s
  def __eq__(self, p ):
    if self.cartesian[0]==p.cartesian[0] and\
       self.cartesian[1]==p.cartesian[1] and\
       self.cartesian[2]==p.cartesian[2]:
      return True
    else:
      return False
