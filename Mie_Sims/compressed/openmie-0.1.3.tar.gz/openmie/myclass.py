# -*- coding: utf-8 -*-
class myclass:
  def __init__(self):
    self.data = 0.
  def add(self, N):
    return self.data + self.function(N)
  def function(self, number ): 
    return number