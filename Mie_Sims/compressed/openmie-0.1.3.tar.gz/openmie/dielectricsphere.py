# -*- coding: utf-8 -*-
#######################################################
#
# OpenMie
#
# A code to calculate Mie scattering from spheres and 
# spherical shells.
#
# See Readme.pdf in documentation directory for theory.
#
# (C) Magnus Lundmark 2009
#######################################################
from numpy import abs,exp
from specialfunctions import *
from constants import j
from field import *

class dielectricsphere:
  'An object returning the scattered field from a dielectric sphere'
  def __init__( self , radius=1. , k0 = 2*pi , N=30 , e_r=1 , mu_r=1 ):
    self.radius = radius
    self.N	= N
    self.k0	= k0
    self.e_r	= e_r
    self.mu_r	= mu_r
    self.kd     = sqrt( e_r*mu_r )*self.k0
    self.eta0	= 377.0
  def ScatteredElectric( self , r_obs ):
  #Return electric field
    r     = r_obs.spherical[0]
    theta = r_obs.spherical[1]
    phi   = r_obs.spherical[2]
    Er     = complex(0.,0.)
    Etheta = complex(0.,0.)
    Ephi   = complex(0.,0.)
    #Return zero field if observation is inside sphere
    if r <= self.radius:
      kr = self.kd*r
      for n in range(1,self.N+1):
	#First compute common function values
	thisPn1S    = Pn1S( n , theta )
	thisPn1pS   = Pn1pS( n , theta )
	thisd_n     = self.d_n( n )
	thise_n     = self.e_n( n )
	thisAltJ    = AltJ( n , kr )
	thisAltJp   = AltJp( n , kr )
	thisa_n     = self.a_n( n )
	#Calculate field sum
	Er =  Er +\
	      n*(n+1)*thisd_n*\
	      thisAltJ*thisPn1S*sin(theta)
	Etheta = Etheta +\
	      thise_n*thisAltJ*thisPn1S -\
	      j*thisd_n*thisAltJp*thisPn1pS
	Ephi = Ephi +\
	      thise_n*thisAltJ*thisPn1pS -\
	      j*thisd_n*thisAltJp*thisPn1S
	#End for loop
      Er     = -Er*cos(phi)*j/(kr)**2
      Etheta = -Etheta*cos(phi)/kr
      Ephi   = -Ephi*sin(phi)/kr
      return field( (Er,Etheta,Ephi) , r_obs , 'spherical' )
    else:
      kr     = self.k0*r  
      for n in range(1,self.N+1):
	#First compute common function values
	thisPn1S      = Pn1S( n , theta )
	thisPn1pS     = Pn1pS( n , theta )
	thisalpha_n   = self.alpha_n( n )
	thisalpha_n_p = self.alpha_n_p( n )
	thisAltH2     = AltH2( n , kr )
	thisAltH2p    = AltH2p( n , kr )
	thisa_n       = self.a_n( n )
	thisb_n       = self.b_n( n )
	thisc_n       = self.c_n( n )
	#Calculate field sum
	Er =     Er +\
	         j**(-n)*(2*n+1)*thisalpha_n_p*\
	         thisAltH2*thisPn1S*sin(theta)
	#Etheta = Etheta +\
	         #thisa_n*( thisalpha_n*thisAltH2*thisPn1S -\
	         #j*thisalpha_n_p*thisAltH2p*thisPn1pS )
	Etheta = Etheta +\
	         ( thisc_n*thisAltH2*thisPn1S -\
	         j*thisb_n*thisAltH2p*thisPn1pS )
	Ephi =   Ephi +\
	         thisa_n*( thisalpha_n*thisAltH2*thisPn1pS -\
	         j*thisalpha_n_p*thisAltH2p*thisPn1S )
	#End for loop
      Er     = Er*cos(phi)*j/(kr)**2
      Etheta = -Etheta*cos(phi)/kr
      Ephi   = Ephi*sin(phi)/kr
      return field( (Er,Etheta,Ephi) , r_obs , 'spherical' )

  def ScatteredMagnetic( self , r_obs ):
  #Return electric field
  # TODO
    r 		= r_obs.spherical[0]
    theta	= r_obs.spherical[1]
    phi		= r_obs.spherical[2]
    #Return zero field if observation is inside sphere
    if r <= self.radius:
      return field( (0.,0.,0.) , r_obs , 'cartesian' )
    else:  
      kr     = self.k0*r
      Hr     = complex(0.,0.)
      Htheta = complex(0.,0.)
      Hphi   = complex(0.,0.)
      for n in range(1,self.N+1):
	#First compute common function values
	thisPn1S      = Pn1S( n , theta )
	thisPn1pS     = Pn1pS( n , theta )
	thisalpha_n   = self.alpha_n( n )
	thisalpha_n_p = self.alpha_n_p( n )
	thisAltH2     = AltH2( n , kr )
	thisAltH2p    = AltH2p( n , kr )
	thisa_n       = self.a_n( n )
	Hr = Hr +\
	     j**(-n)*(2*n+1)*thisalpha_n*thisAltH2*thisPn1S*sin(theta)
	Htheta = Htheta +\
	    thisa_n*( thisalpha_n_p*thisAltH2*thisPn1S -\
	    j*thisalpha_n*thisAltH2p*thisPn1pS )
	Hphi = Hphi +\
	    thisa_n*( thisalpha_n_p*thisAltH2*thisPn1pS -\
	    j*thisalpha_n*thisAltH2p*thisPn1S )
      Hr     =  j*Hr*sin(phi)/(self.eta0*(kr)**2)
      Htheta =    Htheta*sin(phi)/(self.eta0*kr)
      Hphi   =   -Hphi*cos(phi)/(self.eta0*kr)
      return field( (Hr,Htheta,Hphi) , r_obs , 'spherical' )

  def SurfaceCurrentJ( self , r_obs ):
    theta = r_obs.spherical[1]
    phi = r_obs.spherical[2]
    J_t  = complex(0.,0.)
    J_p  = complex(0.,0.)
    k_a = self.k0*self.radius
    eta = self.eta0
    for n in range(1,self.N+1):
      #Calculate temporary function values
      thisPn1S   = Pn1S(n,theta)
      thisPn1pS  = Pn1pS(n,theta)
      thisAltH2p = AltH2p(n,k_a)
      thisAltH2  = AltH2(n,k_a)
      thisa_n    = self.a_n(n)
      J_p = J_p + thisa_n*\
           ( thisPn1S/thisAltH2p +j*thisPn1pS/thisAltH2 )
      J_t = J_t + thisa_n*\
           ( thisPn1pS/thisAltH2p + j*thisPn1S/thisAltH2 )
    J_p = j/eta*sin(phi)/k_a*J_p
    J_t = j/eta*cos(phi)/k_a*J_t
    return field( ( complex(0.,0.) , J_t , J_p ) , r_obs , 'spherical' )

  def SurfaceCurrentM( self , r_obs ):
    theta = r_obs.spherical[1]
    phi = r_obs.spherical[2]
    M_t  = complex(0.,0.)
    M_p  = complex(0.,0.)
    k_a = self.k0*self.radius
    eta = self.eta0
    for n in range(1,self.N+1):
      #Calculate temporary function values
      thisPn1S   = Pn1S(n,theta)
      thisPn1pS  = Pn1pS(n,theta)
      thisAltH2p = AltH2p(n,k_a)
      thisAltH2  = AltH2(n,k_a)
      thisa_n    = self.a_n(n)
      M_p = M_p + thisa_n*\
           ( thisPn1S/thisAltH2p +j*thisPn1pS/thisAltH2 )
      M_t = M_t + thisa_n*\
           ( thisPn1pS/thisAltH2p + j*thisPn1S/thisAltH2 )
    M_p = j/eta*sin(phi)/k_a*J_p
    M_t = j/eta*cos(phi)/k_a*J_t
    return field( ( complex(0.,0.) , M_t , M_p ) , r_obs , 'spherical' )


  def IncidentElectric( self , r_obs ):
  #Return incident electric field
    z = r_obs.cartesian[2]
    return field( ( exp(-j*self.k0*z) , 0. , 0. ) , r_obs , 'cartesian')

  def IncidentMagnetic( self , r_obs ):
  #Return incident magnetic field
    z = r_obs.cartesian[2]
    return field( ( 0. , exp(-j*self.k0*z)/self.eta0 , 0. ) , r_obs , 'cartesian')

  def ScatteredFarField( self , r_obs ):
    theta   = r_obs.spherical[1]
    phi     = r_obs.spherical[2]
    Etheta  = complex(0.,0.)
    Ephi    = complex(0.,0.)
    for n in range(1,self.N+1):
      #Calculate temporary function values
      thisPn1S      = Pn1S(n,theta)
      thisPn1pS     = Pn1pS(n,theta)
      thisn         = (2*n+1.)/(n*(n+1.))
      thisalpha_n   = self.alpha_n( n )
      thisalpha_n_p = self.alpha_n_p( n )
      Etheta = Etheta + thisn*\
           ( thisalpha_n*thisPn1S - thisalpha_n_p*thisPn1pS )
      Ephi = Ephi + thisn*\
           ( thisalpha_n*thisPn1pS - thisalpha_n_p*thisPn1S )
    Etheta = j*cos(phi)/self.k0*Etheta
    Ephi   = j*sin(phi)/self.k0*Ephi
    return field( ( complex(0.,0.) , Etheta , Ephi ) , r_obs , 'spherical' )

  def Ae( self  ):        
    Ae = 0.
    for n in range(1,self.N+1):
      Ae = Ae + (-1)**n*(2*n+1)*( self.alpha_n(n) - self.alpha_n_p(n)  )  
    return abs(Ae)**2*.25/pi

  def Af( self  ):        
    Af = 0.
    for n in range(1,self.N+1):
      Af = Af + (-1)**n*(2*n+1)*( self.alpha_n(n) + self.alpha_n_p(n)  )  
    return abs(Af)**2*.25/pi

  def a_n( self , n  ):
    return j**(-n)*(2*n+1)/(n*(n+1))

  def b_n( self , n ):
  #
    k0a = self.k0*self.radius
    kda = self.kd*self.radius
    nom = sqrt( self.e_r  )*AltJp(n,k0a)*AltJ(n,kda) -\
          sqrt( self.mu_r )*AltJ(n,k0a)*AltJp(n,kda)
    den = sqrt( self.mu_r  )*AltH2(n,k0a)*AltJp(n,kda) -\
          sqrt( self.e_r )*AltH2p(n,k0a)*AltJ(n,kda)
    return  self.a_n(n)*nom/den

  def c_n( self , n ):
  #
    k0a = self.k0*self.radius
    kda = self.kd*self.radius
    nom = -sqrt( self.e_r  )*AltJ(n,k0a)*AltJp(n,kda) +\
          sqrt( self.mu_r )*AltJp(n,k0a)*AltJ(n,kda)
    den = sqrt( self.e_r  )*AltH2(n,k0a)*AltJp(n,kda) -\
          sqrt( self.mu_r )*AltH2p(n,k0a)*AltJ(n,kda)
    return  self.a_n(n)*nom/den

  def alpha_n( self , n  ):
  # alpha = -c_n/a_n
    k0a = self.k0*self.radius
    kda = self.k0*sqrt( self.e_r*self.mu_r )
    nom = sqrt( self.e_r  )*AltJ(n,k0a)*AltJp(n,kda) -\
          sqrt( self.mu_r )*AltJp(n,k0a)*AltJ(n,kda)
    den = sqrt( self.e_r  )*AltH2(n,k0a)*AltJp(n,kda) -\
          sqrt( self.mu_r )*AltH2p(n,k0a)*AltJ(n,kda)
    return  nom/den

  def alpha_n_p( self , n ):
  # alpha_p = -b_n/a_n
    k0a = self.k0*self.radius
    kda = self.k0*sqrt( self.e_r*self.mu_r )
    nom = sqrt( self.e_r  )*AltJp(n,k0a)*AltJ(n,kda) -\
          sqrt( self.mu_r )*AltJ(n,k0a)*AltJp(n,kda)
    den = sqrt( self.e_r  )*AltH2p(n,k0a)*AltJ(n,kda) -\
          sqrt( self.mu_r )*AltH2(n,k0a)*AltJp(n,kda)
    return  nom/den

  def d_n( self , n ):
  #
    k0a = self.k0*self.radius
    kda = self.kd*self.radius
    den = sqrt( self.e_r  )*AltH2p(n,k0a)*AltJ(n,kda) -\
          sqrt( self.mu_r )*AltH2(n,k0a)*AltJp(n,kda)
    return  -self.a_n(n)*j*sqrt( self.e_r )*self.mu_r/den

  def e_n( self , n ):
  #
    k0a = self.k0*self.radius
    kda = self.k0*sqrt( self.e_r*self.mu_r )
    den = sqrt( self.e_r  )*AltH2(n,k0a)*AltJp(n,kda) -\
          sqrt( self.mu_r )*AltH2p(n,k0a)*AltJ(n,kda)
    return   self.a_n(n)*j*sqrt( self.e_r )*self.mu_r/den


  def E_r( self  , r_obs ):
    r     = r_obs.spherical[0]
    theta = r_obs.spherical[1]
    phi   = r_obs.spherical[2]
    E_r   = complex(0.,0.)
    if r < self.radius:
      return
    k0_a = self.k0*self.radius
    k    = self.k0
    for n in range(1,self.N+1):
      E_r = E_r + j**(-n)*(2*n+1)*\
	( AltJ(n, k*r)-self.alpha_n_p(n)*AltH2(n,k*r) )*\
	Pn1S(n,theta)*sin(theta)
    return -E_r*cos(phi)*j/(k*r)**2

  def E_theta( self , r_obs ):
    r       = r_obs.spherical[0]
    theta   = r_obs.spherical[1]
    phi     = r_obs.spherical[2]
    kr      = self.k0*r
    E_theta = complex(0.,0.)
    if r <= self.radius:
      return     
    for n in range(1,self.N+1):
      E_theta = E_theta + self.a_n(n)*\
	( (AltJ(n,kr)-self.alpha_n(n)*AltH2(n,kr) )*Pn1S(n,theta)\
	-j*( AltJp(n,kr)- self.alpha_n_p(n)*AltH2p(n,kr) )*Pn1pS(n,theta))
    return -E_theta*cos(phi)/(k*r)

  def E_phi( self , r_obs ):
    r     = r_obs.spherical[0]
    theta = r_obs.spherical[1]
    phi   = r_obs.spherical[2]
    E_phi = complex(0.,0.)
    if r <= self.radius:
      return 
    k0_a = self.k0*self.radius
    k = self.k0
    for n in range(1,self.N+1):
      E_phi = E_phi +self.a_n(n)*\
	( (AltJ(n,k*r)-self.alpha_n(n)*AltH2(n,k*r))*Pn1pS(n,theta)\
	-j*(AltJp(n,k*r)-self.alpha_n_p(n)*AltH2p(n,k*r))*Pn1S(n,theta) )
    return -E_phi*sin(phi)/(k*r)

  def J_theta( self , r_obs ):
    theta = r_obs.spherical[1]
    phi = r_obs.spherical[2]
    J_t  = complex(0.,0.)
    k_a = self.k0*self.radius
    for n in range(1,self.N+1):
      J_t = J_t + self.a_n(n)*\
	( Pn1pS(n,theta)/AltH2p(n,k_a) + j*Pn1S(n,theta)/AltH2(n,k_a) )
    J_t = j/self.eta0*cos(phi)/k_a*J_t
    return J_t

  def J_phi( self , r_obs ):
    theta = r_obs.spherical[1]
    phi = r_obs.spherical[2]
    J_p  = complex(0.,0.)
    k_a = self.k0*self.radius
    for n in range(1,self.N+1):
      J_p = J_p + self.a_n(n)*\
	( Pn1S(n,theta)/AltH2p(n,k_a) +j*Pn1pS(n,theta)/AltH2(n,k_a) )
    J_p = j/self.eta0*sin(phi)/k_a*J_p
    return J_p


