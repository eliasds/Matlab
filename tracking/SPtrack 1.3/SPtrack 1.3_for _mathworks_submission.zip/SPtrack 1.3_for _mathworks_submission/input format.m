%Format for input through SPT_input


%Mag  Max_X_Y  FPS  Pix_len  No_Frames  T'hold Intensity  FWHM